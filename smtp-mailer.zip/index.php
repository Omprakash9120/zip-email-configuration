<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>
		form mail submited
	</title>
</head>
<body>
	<form action="test.php" method="POST">
		<input type="email" name="email" placeholder="Email"><br>
		<input type="text" name="subject" placeholder="Subject"><br>
		<textarea name="msg" id=""></textarea><br>
		<button type="submit" name="submit">Submit</button>
	</form>
</body>
</html>